package dbms;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TransactionMadeDelete extends JFrame {
	private JTextArea lst;
	private JLabel lblaid;
	private JTextField txtaid;
	private JLabel lblan;
	private JTextField txtan;
	private JButton btn;
	private JPanel pn;
	private JMenu Transaction;
	private JMenu TransactionMade;
	private JMenu ATM;
	private JMenu AccountIn;
	private JMenu Bank;
	private JMenu LinkedTo;
	private JMenu Aadhar;
	private JMenu VerifiedTo;
	private JMenu VerifiedData;
	private JMenuBar menubar;
	private JMenuItem insert1;
	private JMenuItem delete1;
	private JMenuItem view1;
	private JMenuItem insert2;
	private JMenuItem delete2;
	private JMenuItem view2;
	private JMenuItem insert3;
	private JMenuItem delete3;
	private JMenuItem view3;
	private JMenuItem insert4;
	private JMenuItem delete4;
	private JMenuItem view4;
	private JMenuItem insert5;
	private JMenuItem delete5;
	private JMenuItem view5;
	private JMenuItem insert6;
	private JMenuItem delete6;
	private JMenuItem view6;
	private JMenuItem insert7;
	private JMenuItem delete7;
	private JMenuItem view7;
	private JMenuItem insert8;
	private JMenuItem delete8;
	private JMenuItem view8;
	private JMenuItem insert9;
	private JMenuItem view9;
	private JMenuItem delete9;
	public TransactionMadeDelete(){
		pn = new JPanel(new FlowLayout());
		lst = new JTextArea(10,20);
		lblaid = new JLabel("AtmCard Number:");
		txtaid = new JTextField(20);
		lblan = new JLabel("AccountId:");
		txtan = new JTextField(20);
		btn = new JButton("Delete");
		menubar=new JMenuBar();
		Transaction=new JMenu("Transaction");
		insert1=new JMenuItem("Insert");
		view1=new JMenuItem("View");
		delete1=new JMenuItem("Delete");
		Transaction.add(insert1);
		Transaction.add(view1);
		Transaction.add(delete1);
		TransactionMade=new JMenu("TransactionMade");
		insert2=new JMenuItem("Insert");
		view2=new JMenuItem("View");
		delete2=new JMenuItem("Delete");
		TransactionMade.add(insert2);
		TransactionMade.add(view2);
		TransactionMade.add(delete2);
		ATM=new JMenu("ATM");
		insert3=new JMenuItem("Insert");
		view3=new JMenuItem("View");
		delete3=new JMenuItem("Delete");
		ATM.add(insert3);
		ATM.add(view3);
		ATM.add(delete3);
		AccountIn=new JMenu("AccountIn");
		insert4=new JMenuItem("Insert");
		view4=new JMenuItem("View");
		delete4=new JMenuItem("Delete");
		AccountIn.add(insert4);
		AccountIn.add(view4);
		AccountIn.add(delete4);
		Bank=new JMenu("Bank");
		insert5=new JMenuItem("Insert");
		view5=new JMenuItem("View");
		delete5=new JMenuItem("Delete");
		Bank.add(insert5);
		Bank.add(view5);
		Bank.add(delete5);
		LinkedTo=new JMenu("LinkedTo");
		insert6=new JMenuItem("Insert");
		view6=new JMenuItem("View");
		delete6=new JMenuItem("Delete");
		LinkedTo.add(insert6);
		LinkedTo.add(view6);
		LinkedTo.add(delete6);
		Aadhar=new JMenu("Aadhar");
		insert7=new JMenuItem("Insert");
		view7=new JMenuItem("View");
		delete7=new JMenuItem("Delete");
		Aadhar.add(insert7);
		Aadhar.add(view7);
		Aadhar.add(delete7);
		VerifiedTo=new JMenu("VerifiedTo");
		insert8=new JMenuItem("Insert");
		view8=new JMenuItem("View");
		delete8=new JMenuItem("Delete");
		VerifiedTo.add(insert8);
		VerifiedTo.add(view8);
		VerifiedTo.add(delete8);
		VerifiedData=new JMenu("VerifiedData");
		insert9=new JMenuItem("Insert");
		view9=new JMenuItem("View");
		delete9=new JMenuItem("Delete");
		VerifiedData.add(insert9);
		VerifiedData.add(view9);
		VerifiedData.add(delete9);
		this.setSize(600,600);
		this.setVisible(true);
		this.setDefaultCloseOperation(3);
		this.add(pn);
		pn.add(lst);
		pn.add(lblaid);
		pn.add(txtaid);
		pn.add(lblan);
		pn.add(txtan);
		pn.add(btn);
		this.setJMenuBar(menubar);
		menubar.add(Transaction);
		menubar.add(TransactionMade);
		menubar.add(ATM);
		menubar.add(AccountIn);
		menubar.add(Bank);
		menubar.add(LinkedTo);
		menubar.add(Aadhar);
		menubar.add(VerifiedTo);
		menubar.add(VerifiedData);
		insert1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionInsert();
				dispose();
				}
		});
		view1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionView();
				dispose();
			}
		});
		delete1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionDelete();
				dispose();
			}
		});
		insert2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionMadeInsert();
				dispose();
			}
		});
		view2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionMadeView();
				dispose();
			}
		});
		delete2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new TransactionMadeDelete();
				dispose();
			}
		});
		insert3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AtmInsert();
				
				dispose();
			}
		});
		view3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AtmView();
				dispose();
			}
		});
		delete3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AtmDelete();
				dispose();
			}
		});
		insert4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AccountInInsert();
				dispose();
			}
		});
		view4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AccountInView();
				dispose();
			}
		});
		delete4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AccountInDelete();
				dispose();
			}
		});
		insert5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new BankInsert();
				dispose();
			}
		});
		view5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new BankView();
				dispose();
			}
		});
		delete5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new BankDelete();
				dispose();
			}
		});
		insert6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new LinkedToInsert();
				dispose();
			}
		});
		view6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new LinkedToView();
				dispose();
			}
		});
		delete6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new LinkedToDelete();
				dispose();
			}
		});
		insert7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AadharCardInsert();
				dispose();
			}
		});
		view7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AadharCardView();
				dispose();
			}
		});
		delete7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new AadharCardDelete();
				dispose();
			}
		});
		insert8.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new VerifiedToInsert();
				dispose();
			}
		});
		view8.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new VerifiedToView();
				dispose();
			}
		});
		delete8.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new VerifiedToDelete();
				dispose();
			}
		});
		insert9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new VerificationDataInsert();
				dispose();
				
			}
		});
		view9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new VerificationDataView();
				dispose();
			}
		});
		delete9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new VerificationDataDelete();
				dispose();
			}
			
		});	
		try{  
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","pranav","pranav23");  
			  
			Statement stmt=con.createStatement();  
			lst.append("AtmCardNumber   AccountId\n");   
			ResultSet rs=stmt.executeQuery("select * from transactionmade");  
			while(rs.next())  
				lst.append(rs.getString(1)+"      "+rs.getString(2)+"\n");
			  
			  
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String accid=txtaid.getText();
				String acnum=txtan.getText();
				if( accid.compareTo("")==0 || acnum.compareTo("")==0)
				{
					JOptionPane.showMessageDialog(null, "Enter All Fields");
				}
				else
				{
					try{  
						 
						Class.forName("oracle.jdbc.driver.OracleDriver");   
						  
						Connection con=DriverManager.getConnection(  
						"jdbc:oracle:thin:@localhost:1521:xe","pranav","pranav23");  
						  
						Statement stmt=con.createStatement();  
						System.out.println("delete from transactionmade where acnum="+acnum+"and accid="+accid);
						   
						int x=stmt.executeUpdate("delete from transactionmade where acnum="+accid+"and accid="+acnum);  
						con.commit();
						System.out.println("Deleted rows="+x);
						lst.setText("");
						lst.append("AtmCardNumber   AccountId\n");   
						ResultSet rs=stmt.executeQuery("select * from transactionmade");  
						while(rs.next())  
							lst.append(rs.getString(1)+"      "+rs.getString(2)+"\n");
						  
						con.close();  
						  
						}catch(Exception e){ System.out.println(e);} 
					finally
					{
						txtaid.setText("");
						txtan.setText("");
					}
				}
			}
		});
	}
	public static void main(String[] args)
	{
		new TransactionMadeDelete();
	}
}

