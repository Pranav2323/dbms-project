package dbms;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class home extends JFrame{
private JPanel panel1;
private JButton btnMycity;
private JButton btnLandmarks;
private JButton btnServices;
private JButton btnHotels;
private JButton btnMetrostations;
private JButton btnTouristplaces;
private JButton btnHas_Hotels;
private JButton btnHas_metrostations;
private JButton btnHas_touristplaces;
public home()
{
panel1=new JPanel(new GridLayout(3,3,15,15));
btnMetrostations=new JButton("Bank");
btnHas_Hotels=new JButton("Linkedto");
btnHas_metrostations=new JButton("AadharCard");
btnHas_touristplaces=new JButton("VerifiedTo");
btnHotels=new JButton("VerificationData");
btnLandmarks=new JButton("AccountIn");
btnMycity=new JButton("Atm");
btnServices=new JButton("TransactionMade");
btnTouristplaces=new JButton("Transaction");
panel1.setBackground(Color.BLACK);
panel1.add(btnMycity);
panel1.add(btnServices);
panel1.add(btnLandmarks);
panel1.add(btnHotels);
panel1.add(btnMetrostations);
panel1.add(btnTouristplaces);
panel1.add(btnHas_Hotels);
panel1.add(btnHas_metrostations);
panel1.add(btnHas_touristplaces);
this.setVisible(true);
this.setSize(600,400);
this.setDefaultCloseOperation(3);
this.add(panel1,BorderLayout.CENTER);
btnHas_Hotels.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new LinkedToView();
dispose();
}
});
btnHas_metrostations.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new AadharCardView();
dispose();
}
});
btnHas_touristplaces.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new VerifiedToView();
dispose();
}
});
btnHotels.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new VerificationDataView();
dispose();
}
});
btnLandmarks.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new AccountInView();
dispose();
}
});
btnMetrostations.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new BankView();
dispose();
}
});
btnMycity.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new AtmView();
dispose();
}
});
btnServices.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new TransactionMadeView();
dispose();
}
});
btnTouristplaces.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
new TransactionView();
dispose();
}
});
}
public static void main(String args[])
{
new home();
}

}
